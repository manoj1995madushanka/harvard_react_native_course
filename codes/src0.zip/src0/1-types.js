const x = 42

// get type by using "typeof"
console.log(typeof x)
console.log(typeof undefined)

// this may surprise you...
console.log(typeof null)
