const list = document.getElementById('todo-list')
const itemCountSpan = document.getElementById('item-count')
const uncheckedCountSpan = document.getElementById('unchecked-count')

//  <li>
//    <input type="checkbox" />
//    <button>delete</button>
//    <span>text</span>
//  </li>

function newTodo() {
  // get text
  // create li
  // create input checkbox
  // create button
  // create span
  // update counts
}

function deleteTodo() {
  // find the todo to delete
  // delete
  // update the counts
}
